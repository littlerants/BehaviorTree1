from srunner.osc2.symbol_manager.scope import Scope
from srunner.osc2.symbol_manager.symbol import Symbol


class CompoundSymbol(Symbol, Scope):
    pass
